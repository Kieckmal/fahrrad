import fs from 'node:fs/promises';
import path from 'node:path';
import { chromium } from 'playwright';

const root = path.resolve(new URL('..', import.meta.url).pathname);
const config = JSON.parse(await fs.readFile(path.join(root, 'data/config.json'), 'utf8'));
const previous = JSON.parse(await fs.readFile(path.join(root, 'data/offers.json'), 'utf8'));

function normalizeSize(text = '') {
  const t = text.toUpperCase().replace(/RH|GRÖSSE|SIZE|CM|RAHMENHÖHE/g, ' ');
  return config.acceptedSizes.find(size => new RegExp(`(^|\\D)${size}($|\\D)`, 'i').test(t)) ?? null;
}

function priceFrom(text = '') {
  const match = text.replace(/\./g, '').match(/(\d{3,5})(?:,\d{2})?\s*€/);
  return match ? Number(match[1]) : null;
}

function modelFrom(text = '') {
  return config.models.find(model => text.toLowerCase().includes(model.toLowerCase())) ?? null;
}

async function scanSource(browser, source) {
  const page = await browser.newPage({ locale: 'de-DE', userAgent: 'Mozilla/5.0 FahrradDealTracker/0.1' });
  try {
    await page.goto(source.url, { waitUntil: 'domcontentloaded', timeout: 45000 });
    const links = await page.locator('a').evaluateAll(nodes => nodes.slice(0, 1200).map(a => ({
      text: (a.innerText || '').trim(), href: a.href
    })).filter(x => x.text && x.href));

    const offers = [];
    for (const link of links) {
      const model = modelFrom(link.text);
      const size = normalizeSize(link.text);
      const price = priceFrom(link.text);
      if (!model || !size) continue;
      if (price && price > config.maxPriceEur) continue;
      offers.push({
        id: `${source.id}:${link.href}`,
        source: source.name,
        sourceType: source.type,
        model,
        size,
        price,
        title: link.text.replace(/\s+/g, ' ').slice(0, 180),
        url: link.href,
        condition: /gebraucht|used|refurbished/i.test(link.text) ? 'Gebraucht' : 'Unbekannt',
        foundAt: new Date().toISOString()
      });
    }
    return offers;
  } catch (error) {
    console.error(`[${source.name}] ${error.message}`);
    return [];
  } finally {
    await page.close();
  }
}

const browser = await chromium.launch({ headless: true });
const all = [];
for (const source of config.sources.filter(s => s.enabled)) {
  all.push(...await scanSource(browser, source));
}
await browser.close();

const merged = new Map(previous.offers.map(o => [o.id, o]));
for (const offer of all) merged.set(offer.id, { ...merged.get(offer.id), ...offer });
const offers = [...merged.values()].sort((a, b) => (a.price ?? Infinity) - (b.price ?? Infinity));
await fs.writeFile(path.join(root, 'data/offers.json'), JSON.stringify({ updatedAt: new Date().toISOString(), offers }, null, 2));
await fs.copyFile(path.join(root, 'data/offers.json'), path.join(root, 'public/offers.json'));
await fs.copyFile(path.join(root, 'data/config.json'), path.join(root, 'public/config.json'));
console.log(`${offers.length} Angebote gespeichert.`);
